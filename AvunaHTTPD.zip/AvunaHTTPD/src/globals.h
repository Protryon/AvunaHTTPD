/*
 * globals.h
 *
 *  Created on: Nov 19, 2015
 *      Author: root
 */

#ifndef GLOBALS_H_
#define GLOBALS_H_

struct config* cfg;
struct logsess* delog;
size_t mime_count;
struct mime** mimes;

#endif /* GLOBALS_H_ */
