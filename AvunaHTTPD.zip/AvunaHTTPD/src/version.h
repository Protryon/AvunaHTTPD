/*
 * version.h
 *
 *  Created on: Nov 18, 2015
 *      Author: root
 */

#ifndef VERSION_H_
#define VERSION_H_

#define VERSION "2.0.0"
#define DAEMON_NAME "HTTPD"
#define DEBUG

#endif /* VERSION_H_ */
